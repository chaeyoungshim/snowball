/**
 * 
 */
 $(function(){
 	
 	//돌아가기 버튼 주소 걸어주기
// 	$(".back-admin").click(function(){
// 		location.href = "/admin/index";
// 	})
 	
 	$(".back-user").click(function(){
 		location.href = "/user/index";
 	})
 	
 })